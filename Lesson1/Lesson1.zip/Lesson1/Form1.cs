﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lesson1
{
    public partial class Form1 : Form
    {
        private Int32 cnt;
        public Form1()
        {
            InitializeComponent();
            cnt = 0;
        }

        private void buttonTrap_Click(object sender, EventArgs e)
        {
            cnt++;
            labelDemo.Text = $"Oh no, you will be eaten by SuperBattleSharkX228 {cnt} times!!1!!1";
        }
    }
}
